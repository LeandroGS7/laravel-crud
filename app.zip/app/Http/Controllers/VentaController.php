<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Venta;
use App\Models\Cliente;
use App\Models\Productos;
use Illuminate\support\Facades\DB;

class VentaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ventas = Venta::all();
        return view('venta.index')->with('ventas',$ventas);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $productos = Productos::all();

        return view('venta.create')->with('productos',$productos);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $venta = new Venta();
        $prod = Productos::find($request->id_producto);
        $cliente = Cliente::where('documento', $request->documento);
        
        $venta->fecha = $request->fecha;
        $venta->id_producto = $prod->producto_id;
        $venta->id_cliente = 1;
        $venta->valor = ($prod->precio)*$request->cantidad;
        $cantidad = $request->cantidad;

        $venta->save();
        return redirect('/venta')->with('cantidad',$cantidad);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $ventas = Venta::find($id);
        return view('venta.edit')->with('ventas',$ventas);
    }
    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $venta = Venta::find($id);

        $venta->nombre = $request->nombre;
        $venta->documento = $request->documento;
        $venta->correo = $request->correo;
        $venta->celular = $request->celular;        

        $venta->save();
        return redirect('/venta');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $venta = Venta::find($id);
        $venta->delete();

        return redirect('/venta');
    }
}