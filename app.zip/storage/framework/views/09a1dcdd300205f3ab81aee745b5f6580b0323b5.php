;

<?php $__env->startSection('contenido'); ?>
<h2 style="text-align:center;">Editar Informacion Cliente</h2>

<form action="/cliente/<?php echo e($clientes->cliente_id); ?>" method="POST">
    <?php echo method_field('PUT'); ?>    
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="" class="form-label">Nombre</label>
        <input type="text" name="nombre" class="form-control" id="nombre" value="<?php echo e($clientes->nombre); ?>" tabindex="1">
    </div>
    <div class="mb-3">
        <label for="" class="form-label">Documento</label>
        <input type="text" name="documento" class="form-control" id="documento" value="<?php echo e($clientes->documento); ?>" tabindex="2">
    </div>

    <div class="mb-3">
        <label for="" class="form-label">Correo</label>
        <input type="text" name="correo" class="form-control" id="correo" value="<?php echo e($clientes->correo); ?>" tabindex="3">
    </div>

    <div class="mb-3">
        <label for="" class="form-label">Celular</label>
        <input type="text" name="celular" class="form-control" id="celular" value="<?php echo e($clientes->celular); ?>" tabindex="4">
    </div>

    <a href="/cliente" class="btn btn-secondary" tabindex="5">Cancelar</a>
    <button type="submit" class="btn btn-primary" tabindex="4">Guardar</button>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\leang\programacion_web\resources\views/cliente/edit.blade.php ENDPATH**/ ?>