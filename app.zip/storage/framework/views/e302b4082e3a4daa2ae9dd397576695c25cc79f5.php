

<?php $__env->startSection('contenido'); ?>
    <a href="cliente/create" class="btn btn-primary">AGREGAR CLIENTE</a>
    <table class="table table-dark table-striped mt-4">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nombre</th>
                <th scope="col">Documento</th>
                <th scope="col">Correo</th>
                <th scope="col">Celular</th>
                <th scope="col">Acciones</th>
            </tr>
        </thead>
        <tbody>
            
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cliente->cliente_id); ?></td>
                <td><?php echo e($cliente->nombre); ?></td>
                <td><?php echo e($cliente->documento); ?></td>
                <td><?php echo e($cliente->correo); ?></td>
                <td><?php echo e($cliente->celular); ?></td>
                <td>
                    <form action="<?php echo e(route ('cliente.destroy',$cliente->cliente_id)); ?>" method="POST">
                        <a href="/cliente/<?php echo e($cliente->cliente_id); ?>/edit" class="btn btn-info">Editar</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Borrar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\leang\programacion_web\resources\views/cliente/index.blade.php ENDPATH**/ ?>