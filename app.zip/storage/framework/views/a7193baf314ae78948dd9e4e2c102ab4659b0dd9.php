

<?php $__env->startSection('contenido'); ?>
    <a href="venta/create" class="btn btn-primary">Realizar Venta</a>
    <table class="table table-dark table-striped mt-4">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Fecha</th>
                <th scope="col">Valor</th>
                <th scope="col">Producto</th>
                <th scope="col">Cliente</th>
                <th scope="col">Acciones</th>
            </tr>
        </thead>
        <tbody>
            
            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($venta->venta_id); ?></td>
                <td><?php echo e($venta->fecha); ?></td>
                <td><?php echo e($venta->valor); ?></td>
                <td><?php echo e($venta->id_producto); ?></td>
                <td><?php echo e($venta->id_cliente); ?></td>
                <td>
                    <form action="<?php echo e(route ('venta.destroy',$venta->venta_id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Borrar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\leang\programacion_web\resources\views/venta/index.blade.php ENDPATH**/ ?>