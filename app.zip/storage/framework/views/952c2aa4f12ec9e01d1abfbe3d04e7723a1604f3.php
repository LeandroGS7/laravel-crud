;

<?php $__env->startSection('contenido'); ?>
<h2 style="text-align:center;">Editar Producto</h2>

<form action="/productos/<?php echo e($productos->producto_id); ?>" method="POST">
    <?php echo method_field('PUT'); ?>    
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="" class="form-label">nombre</label>
        <input type="text" name="nombre" class="form-control" id="nombre" value="<?php echo e($productos->nombre); ?>" tabindex="1">
    </div>
    <div class="mb-3">
        <label for="" class="form-label">descripcion</label>
        <input type="text" name="descripcion" class="form-control" value="<?php echo e($productos->descripcion); ?>" id="descripcion" tabindex="2">
    </div>

    <div class="mb-3">
        <label for="" class="form-label">precio</label>
        <input type="text" name="precio" class="form-control" value="<?php echo e($productos->precio); ?>" id="precio" tabindex="3">
    </div>
    <a href="/productos" class="btn btn-secondary" tabindex="5">Cancelar</a>
    <button type="submit" class="btn btn-primary" tabindex="4">Guardar</button>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\leang\programacion_web\resources\views/productos/edit.blade.php ENDPATH**/ ?>