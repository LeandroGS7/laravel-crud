<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Venta extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('venta', function (Blueprint $table) {
            $table->bigIncrements('venta_id');
            $table->float('valor');
            $table->date('fecha');
            $table->bigInteger('id_producto')->unsigned();
            $table->bigInteger('id_cliente')->unsigned();
            $table->foreign('id_producto')->references('producto_id')->on('productos')->onDelete("cascade");
            $table->foreign('id_cliente')->references('cliente_id')->on('cliente')->onDelete("cascade");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('venta');
    }
}