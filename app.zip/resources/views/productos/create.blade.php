@extends('layouts.plantillabase');

@section('contenido')
<h2 style="text-align:center;">Crear Producto</h2>

<form action="/productos" method="POST">
    @csrf
    <div class="mb-3">
        <label for="" class="form-label">nombre</label>
        <input type="text" name="nombre" class="form-control" id="nombre" tabindex="1">
    </div>
    <div class="mb-3">
        <label for="" class="form-label">descripcion</label>
        <input type="text" name="descripcion" class="form-control" id="descripcion" tabindex="2">
    </div>

    <div class="mb-3">
        <label for="" class="form-label">precio</label>
        <input type="text" name="precio" class="form-control" id="precio" tabindex="3">
    </div>
    <a href="/productos" class="btn btn-secondary" tabindex="5">Cancelar</a>
    <button type="submit" class="btn btn-primary" tabindex="4">Guardar</button>

@endsection