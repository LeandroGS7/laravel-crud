@extends('layouts.plantillabase');

@section('contenido')
<h2 style="text-align:center;">Crear Cliente</h2>

<form action="/cliente" method="POST">
    @csrf
    <div class="mb-3">
        <label for="" class="form-label">Nombre</label>
        <input type="text" name="nombre" class="form-control" id="nombre" tabindex="1">
    </div>
    <div class="mb-3">
        <label for="" class="form-label">documento</label>
        <input type="text" name="documento" class="form-control" id="documento" tabindex="2">
    </div>

    <div class="mb-3">
        <label for="" class="form-label">Correo</label>
        <input type="text" name="correo" class="form-control" id="correo" tabindex="3">
    </div>

    <div class="mb-3">
        <label for="" class="form-label">Celular</label>
        <input type="text" name="celular" class="form-control" id="celular" tabindex="4">
    </div>

    <a href="/cliente" class="btn btn-secondary" tabindex="5">Cancelar</a>
    <button type="submit" class="btn btn-primary" tabindex="4">Guardar</button>

@endsection