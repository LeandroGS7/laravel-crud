@extends('layouts.plantillabase');

@section('contenido')
<h2 style="text-align:center;">Realizar Venta</h2>

<form action="/venta" method="POST">
    @csrf
    <div class="mb-3">
        <label for="" class="form-label">Fecha</label>
        <input type="text" name="fecha" class="form-control" id="fecha" placeholder="aaaa/mm/dd" tabindex="1">
    </div>
    <div class="mb-3">
        <label for="" class="form-label">Documento cliente</label>
        <input type="text" name="documento" class="form-control" id="documento" tabindex="2">
    </div>

    <div class="mb-3">
        <label for="" class="form-label">Id Producto</label>
        <input type="text" name="id_producto" class="form-control" id="id_producto" tabindex="3">                
    </div> 

    <div class="mb-3">
        <label for="" class="form-label">Cantidad</label>
        <input type="number" name="cantidad" class="form-control" id="cantidad" tabindex="4">
    </div>

    <a href="/cliente" class="btn btn-secondary" tabindex="5">Cancelar</a>
    <button type="submit" class="btn btn-primary" tabindex="4">Guardar</button>

</form>

<br><br><h2 style="text-align:center;">Productos Disponibles</h2><br><br>
<table class="table table-dark table-striped mt-4">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nombre</th>
                <th scope="col">Descripción</th>
                <th scope="col">Precio</th>
            </tr>
        </thead>
        <tbody>
            
            @foreach($productos as $producto)
            <tr>
                <td>{{$producto->producto_id}}</td>
                <td>{{$producto->nombre}}</td>
                <td>{{$producto->descripcion}}</td>
                <td>{{$producto->precio}}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

@endsection